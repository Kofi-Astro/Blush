"""
ORM models — these map onto the tables created by schema.sql.
This file does not create or alter tables; schema.sql remains the
source of truth for the database structure.
"""
import uuid
from datetime import date, datetime

from sqlalchemy import CheckConstraint, Date, DateTime, ForeignKey, SmallInteger, String, Text, Boolean
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.database import Base


class PortfolioCategory(Base):
    __tablename__ = "portfolio_categories"

    id: Mapped[int] = mapped_column(SmallInteger, primary_key=True)
    name: Mapped[str] = mapped_column(String(60), unique=True, nullable=False)
    slug: Mapped[str] = mapped_column(String(60), unique=True, nullable=False)

    items: Mapped[list["PortfolioItem"]] = relationship(back_populates="category")


class ServiceType(Base):
    __tablename__ = "service_types"

    id: Mapped[int] = mapped_column(SmallInteger, primary_key=True)
    name: Mapped[str] = mapped_column(String(80), unique=True, nullable=False)
    slug: Mapped[str] = mapped_column(String(60), unique=True, nullable=False)


class PortfolioItem(Base):
    __tablename__ = "portfolio_items"

    id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    title: Mapped[str] = mapped_column(String(150), nullable=False)
    description: Mapped[str | None] = mapped_column(Text, nullable=True)
    image_url: Mapped[str] = mapped_column(Text, nullable=False)
    look_number: Mapped[int | None] = mapped_column(SmallInteger, nullable=True)
    category_id: Mapped[int] = mapped_column(SmallInteger, ForeignKey("portfolio_categories.id"), nullable=False)
    is_featured: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    display_order: Mapped[int] = mapped_column(default=0, nullable=False)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=datetime.utcnow)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=datetime.utcnow)

    category: Mapped["PortfolioCategory"] = relationship(back_populates="items")


class ConsultationRequest(Base):
    __tablename__ = "consultation_requests"

    id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    full_name: Mapped[str] = mapped_column(String(150), nullable=False)
    email: Mapped[str] = mapped_column(String(255), nullable=False)
    phone: Mapped[str] = mapped_column(String(30), nullable=False)
    service_type_id: Mapped[int | None] = mapped_column(
        SmallInteger, ForeignKey("service_types.id", ondelete="SET NULL"), nullable=True
    )
    preferred_date: Mapped[date | None] = mapped_column(Date, nullable=True)
    design_requirements: Mapped[str | None] = mapped_column(Text, nullable=True)
    status: Mapped[str] = mapped_column(String(20), default="pending", nullable=False)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=datetime.utcnow)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=datetime.utcnow)

    service_type: Mapped["ServiceType | None"] = relationship()

    __table_args__ = (
        CheckConstraint(
            "status IN ('pending','confirmed','in_progress','completed','cancelled')",
            name="chk_consultation_status",
        ),
    )
