"""
POST /api/consultations

Receives the booking form submission from the frontend, validates it,
and writes it to consultation_requests. This is the only endpoint on
this API that writes data, so it gets the most scrutiny:

  - Pydantic validates every field's type/length/format before any
    database call happens.
  - SQLAlchemy's ORM parameterizes all values automatically, so
    user input can never be interpolated into raw SQL (no injection).
  - A honeypot field silently discards bot submissions.
  - slowapi rate-limits repeated submissions per IP.
  - CORS (configured in main.py) restricts which frontends may call this.
"""
import uuid
from datetime import datetime

from fastapi import APIRouter, Depends, HTTPException, Request, status
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.database import get_db
from app.models import ConsultationRequest, ServiceType
from app.schemas import ConsultationCreate, ConsultationOut
from app.security import limiter
from app.config import settings

router = APIRouter(prefix="/api/consultations", tags=["consultations"])


@router.post("", response_model=ConsultationOut, status_code=status.HTTP_201_CREATED)
@limiter.limit(settings.consultation_rate_limit)
async def create_consultation(
    request: Request,               # required by slowapi's @limiter.limit
    payload: ConsultationCreate,
    db: AsyncSession = Depends(get_db),
) -> ConsultationRequest:
    # Honeypot check — real visitors never populate this field (it's
    # hidden off-screen on the frontend). Return a normal-looking
    # success response so bots don't learn their submission was
    # rejected, but never touch the database.
    if payload.website:
        return ConsultationOut(
            id=uuid.uuid4(),
            full_name=payload.full_name,
            status="pending",
            created_at=datetime.utcnow(),
        )

    # Resolve the service slug (e.g. "bridal") sent by the <select> on
    # the frontend into the service_types row it refers to.
    service_type = None
    if payload.service_slug:
        result = await db.execute(
            select(ServiceType).where(ServiceType.slug == payload.service_slug)
        )
        service_type = result.scalar_one_or_none()
        if service_type is None:
            raise HTTPException(
                status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
                detail=f"Unknown service '{payload.service_slug}'.",
            )

    new_request = ConsultationRequest(
        full_name=payload.full_name,
        email=payload.email,
        phone=payload.phone,
        service_type_id=service_type.id if service_type else None,
        preferred_date=payload.preferred_date,
        design_requirements=payload.design_requirements,
        status="pending",
    )

    db.add(new_request)
    await db.commit()
    await db.refresh(new_request)

    return new_request
