"""
GET /api/portfolio

Read-only endpoint that feeds the homepage Lookbook grid. Supports an
optional ?category= filter matching the frontend's filter pills
(all | rtw | bridal | custom).
"""
from fastapi import APIRouter, Depends, Query
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload

from app.database import get_db
from app.models import PortfolioItem
from app.schemas import PortfolioItemOut, PortfolioListResponse

router = APIRouter(prefix="/api/portfolio", tags=["portfolio"])


@router.get("", response_model=PortfolioListResponse)
async def list_portfolio_items(
    category: str | None = Query(
        default=None,
        description="Filter by category slug: rtw, bridal, or custom. Omit for all.",
    ),
    db: AsyncSession = Depends(get_db),
) -> PortfolioListResponse:
    stmt = (
        select(PortfolioItem)
        .options(selectinload(PortfolioItem.category))
        .order_by(PortfolioItem.display_order, PortfolioItem.look_number)
    )

    if category and category != "all":
        stmt = stmt.where(PortfolioItem.category.has(slug=category))

    result = await db.execute(stmt)
    items = result.scalars().all()

    out_items = [
        PortfolioItemOut(
            id=item.id,
            title=item.title,
            description=item.description,
            image_url=item.image_url,
            look_number=item.look_number,
            category=item.category.slug,
            category_label=item.category.name,
            is_featured=item.is_featured,
        )
        for item in items
    ]

    return PortfolioListResponse(count=len(out_items), items=out_items)
