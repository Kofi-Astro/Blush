"""
Blush Closet API — entrypoint.

Run locally with:
    uvicorn app.main:app --reload

Endpoints:
    POST /api/consultations   — submit the booking form
    GET  /api/portfolio       — fetch Lookbook items for the homepage
    GET  /healthz             — liveness check
"""
from fastapi import FastAPI, Request
from fastapi.exceptions import RequestValidationError
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from slowapi.errors import RateLimitExceeded

from app.config import settings
from app.routers import consultations, portfolio
from app.security import limiter

app = FastAPI(
    title="Blush Closet API",
    description="Backend for the Blush Closet consultation form and Lookbook.",
    version="1.0.0",
    # Hide interactive docs in production so the schema isn't public.
    docs_url=None if settings.is_production else "/docs",
    redoc_url=None if settings.is_production else "/redoc",
)

# --- Rate limiting (protects POST /api/consultations from spam) ---------
app.state.limiter = limiter


@app.exception_handler(RateLimitExceeded)
async def rate_limit_handler(request: Request, exc: RateLimitExceeded) -> JSONResponse:
    return JSONResponse(
        status_code=429,
        content={"detail": "Too many requests. Please try again in a moment."},
    )


# --- CORS: only the frontend origins listed in ALLOWED_ORIGINS may call this API ---
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.cors_origins,
    allow_credentials=False,
    allow_methods=["GET", "POST"],
    allow_headers=["Content-Type"],
)


# --- Clean validation error messages instead of raw Pydantic tracebacks ---
@app.exception_handler(RequestValidationError)
async def validation_exception_handler(request: Request, exc: RequestValidationError) -> JSONResponse:
    errors = [
        {"field": ".".join(str(loc) for loc in err["loc"] if loc != "body"), "message": err["msg"]}
        for err in exc.errors()
    ]
    return JSONResponse(status_code=422, content={"detail": "Validation failed.", "errors": errors})


# --- Routers --------------------------------------------------------------
app.include_router(consultations.router)
app.include_router(portfolio.router)


@app.get("/healthz", tags=["meta"])
async def healthz() -> dict[str, str]:
    return {"status": "ok"}
