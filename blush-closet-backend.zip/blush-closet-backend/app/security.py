"""
Cross-cutting security helpers: rate limiting for public endpoints.
Booking spam / scraping abuse is the main threat model for this API,
since both endpoints are intentionally public (no login).
"""
from slowapi import Limiter
from slowapi.util import get_remote_address

limiter = Limiter(key_func=get_remote_address)
