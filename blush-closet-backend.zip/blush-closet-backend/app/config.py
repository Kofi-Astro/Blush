"""
Application configuration.

All secrets and environment-specific values (DB credentials, allowed
CORS origins, etc.) are loaded from environment variables / a .env
file — never hardcoded. See .env.example for the variables this
expects.
"""
from functools import lru_cache
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    # --- Database -----------------------------------------------------
    postgres_user: str
    postgres_password: str
    postgres_host: str = "localhost"
    postgres_port: int = 5432
    postgres_db: str = "blush_closet"

    # Optional: if a full DATABASE_URL is provided (common on hosts
    # like Render/Railway/Heroku), it takes precedence over the
    # individual fields above.
    database_url_override: str | None = None

    # --- App ------------------------------------------------------------
    environment: str = "development"          # development | production
    allowed_origins: str = "http://localhost:5500,http://127.0.0.1:5500"

    # --- Rate limiting ---------------------------------------------------
    consultation_rate_limit: str = "5/minute"  # protects the public booking endpoint

    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        extra="ignore",
    )

    @property
    def database_url(self) -> str:
        """
        Build the SQLAlchemy async connection string.

        Uses the asyncpg driver: postgresql+asyncpg://user:pass@host:port/db
        A fully-formed DATABASE_URL env var (if set) always wins, since
        most managed Postgres providers inject one automatically.
        """
        if self.database_url_override:
            url = self.database_url_override
            # Normalize "postgres://" / plain "postgresql://" (what most
            # hosting providers hand you) to the asyncpg driver FastAPI needs.
            if url.startswith("postgres://"):
                url = url.replace("postgres://", "postgresql+asyncpg://", 1)
            elif url.startswith("postgresql://"):
                url = url.replace("postgresql://", "postgresql+asyncpg://", 1)
            return url

        return (
            f"postgresql+asyncpg://{self.postgres_user}:{self.postgres_password}"
            f"@{self.postgres_host}:{self.postgres_port}/{self.postgres_db}"
        )

    @property
    def cors_origins(self) -> list[str]:
        return [origin.strip() for origin in self.allowed_origins.split(",") if origin.strip()]

    @property
    def is_production(self) -> bool:
        return self.environment.lower() == "production"


@lru_cache
def get_settings() -> Settings:
    # Cached so the .env file is only parsed once per process.
    return Settings()


settings = get_settings()
