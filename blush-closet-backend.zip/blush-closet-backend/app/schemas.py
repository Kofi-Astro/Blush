"""
Pydantic schemas: request validation + response shaping.

Keeping these separate from the ORM models means the API never
serializes a raw database row back to the client by accident, and
every inbound field gets validated (type, length, format) before it
touches the database.
"""
import re
import uuid
from datetime import date, datetime

from pydantic import BaseModel, ConfigDict, EmailStr, Field, field_validator

PHONE_PATTERN = re.compile(r"^[0-9+()\-\s]{7,30}$")


# ============================================================
# Consultation requests (the booking form)
# ============================================================
class ConsultationCreate(BaseModel):
    full_name: str = Field(..., min_length=2, max_length=150)
    email: EmailStr
    phone: str = Field(..., min_length=7, max_length=30)
    service_slug: str = Field(..., description="One of: bridal, rtw, custom, alterations")
    preferred_date: date | None = None
    design_requirements: str | None = Field(default=None, max_length=2000)

    # Honeypot field: real users never see or fill this (hidden via CSS on
    # the frontend). If it arrives non-empty, the submission is a bot.
    website: str | None = Field(default=None, max_length=0)

    @field_validator("full_name")
    @classmethod
    def strip_and_check_name(cls, v: str) -> str:
        v = v.strip()
        if not v:
            raise ValueError("Full name cannot be empty.")
        return v

    @field_validator("phone")
    @classmethod
    def validate_phone(cls, v: str) -> str:
        v = v.strip()
        if not PHONE_PATTERN.match(v):
            raise ValueError("Phone number contains invalid characters.")
        return v

    @field_validator("design_requirements")
    @classmethod
    def strip_requirements(cls, v: str | None) -> str | None:
        if v is None:
            return v
        # Strip control characters; HTML-escaping happens at render time
        # wherever this text is later displayed (e.g. an admin dashboard).
        return re.sub(r"[\x00-\x08\x0b\x0c\x0e-\x1f]", "", v).strip() or None

    @field_validator("preferred_date")
    @classmethod
    def validate_future_date(cls, v: date | None) -> date | None:
        if v is not None and v < date.today():
            raise ValueError("Preferred date must be today or in the future.")
        return v


class ConsultationOut(BaseModel):
    id: uuid.UUID
    full_name: str
    status: str
    created_at: datetime

    model_config = ConfigDict(from_attributes=True)


# ============================================================
# Portfolio items (the Lookbook grid)
# ============================================================
class PortfolioItemOut(BaseModel):
    id: uuid.UUID
    title: str
    description: str | None
    image_url: str
    look_number: int | None
    category: str          # category slug, e.g. "rtw" — matches frontend data-filter values
    category_label: str    # human-readable name, e.g. "Ready-to-Wear"
    is_featured: bool

    model_config = ConfigDict(from_attributes=True)


class PortfolioListResponse(BaseModel):
    count: int
    items: list[PortfolioItemOut]
