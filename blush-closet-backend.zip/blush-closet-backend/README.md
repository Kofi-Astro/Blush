# Blush Closet API

FastAPI backend connecting the Blush Closet frontend to PostgreSQL (schema: `schema.sql` from the previous step).

## Project layout

```
app/
  main.py                 FastAPI app: CORS, rate limiting, routers
  config.py                Settings + connection-string logic (env-based)
  database.py               Async SQLAlchemy engine/session
  models.py                  ORM models mapped to schema.sql's tables
  schemas.py                  Pydantic request/response validation
  routers/
    consultations.py          POST /api/consultations
    portfolio.py                GET  /api/portfolio
requirements.txt
.env.example
```

## Setup

```bash
python -m venv venv
source venv/bin/activate            # Windows: venv\Scripts\activate
pip install -r requirements.txt

cp .env.example .env                # then fill in real DB credentials
uvicorn app.main:app --reload       # http://localhost:8000
```

Interactive API docs (dev only, disabled in production): `http://localhost:8000/docs`

## Connection string logic

`app/config.py` builds the SQLAlchemy connection string from environment
variables — nothing is hardcoded. Two ways to configure it:

1. **Individual fields** (`POSTGRES_USER`, `POSTGRES_PASSWORD`,
   `POSTGRES_HOST`, `POSTGRES_PORT`, `POSTGRES_DB`) — combined into:
   ```
   postgresql+asyncpg://{user}:{password}@{host}:{port}/{db}
   ```
2. **A single `DATABASE_URL_OVERRIDE`** — used as-is if set (handy for
   managed hosts like Render/Railway/Supabase that inject one variable).
   `postgres://` and `postgresql://` prefixes are auto-converted to
   `postgresql+asyncpg://`, since SQLAlchemy needs the driver named
   explicitly for async support.

Either way, the app never sees a credential unless it comes from the
environment — see `.env.example` for the full variable list.

## Endpoints

### `POST /api/consultations`
Submits the booking form into `consultation_requests`.

```json
{
  "full_name": "Ama Mensah",
  "email": "ama@email.com",
  "phone": "+233 24 555 0199",
  "service_slug": "bridal",
  "preferred_date": "2026-09-12",
  "design_requirements": "Ivory gown, long train, September wedding."
}
```
→ `201` with the created record's `id`, `status` ("pending"), and `created_at`.

### `GET /api/portfolio?category=rtw`
Fetches Lookbook items for the homepage grid. `category` is optional
(`rtw`, `bridal`, `custom`, or omitted for all).

```json
{
  "count": 2,
  "items": [
    {
      "id": "…",
      "title": "Ivory Column",
      "description": null,
      "image_url": "https://…",
      "look_number": 1,
      "category": "rtw",
      "category_label": "Ready-to-Wear",
      "is_featured": true
    }
  ]
}
```

## How form submissions are secured

- **Validation before persistence** — every field is type-, length-, and
  format-checked by Pydantic (`schemas.py`) before it reaches the database.
  Invalid phone formats, malformed emails, and past-dated bookings are
  rejected with a 422 and a clear field-level message.
- **No SQL injection surface** — all queries go through SQLAlchemy's ORM,
  which parameterizes every value. User input is never string-concatenated
  into SQL.
- **Honeypot field** — the request schema includes a hidden `website`
  field. Real visitors never see or fill it (hide it off-screen with CSS
  on the frontend); if it arrives populated, the submission is silently
  discarded without a database write, while still returning a normal
  success response so bots can't tell they were caught.
- **Rate limiting** — `POST /api/consultations` is capped (default
  5/minute per IP, via `slowapi`) to blunt scripted spam.
- **Locked-down CORS** — only origins listed in `ALLOWED_ORIGINS` may
  call the API from a browser; everything else is rejected before it
  reaches your route code.
- **Docs hidden in production** — `/docs` and `/redoc` are disabled when
  `ENVIRONMENT=production`, so the schema isn't exposed publicly.

Two things worth adding before a real production launch, outside this
file's scope: TLS termination (usually handled by your host/reverse
proxy, e.g. Nginx or a platform like Render) and an email notification
on new consultation requests (e.g. via a transactional email API).

## Wiring up the existing frontend

Replace the demo `fetch`-free submit handler in `index.html`'s
`<script>` with a real call. The shape of the payload maps directly onto
the form's existing field names:

```javascript
const API_BASE = "https://api.blushcloset.com"; // or http://localhost:8000 locally

form.addEventListener('submit', async function (e) {
  e.preventDefault();
  // ...existing per-field validation stays the same...

  const payload = {
    full_name: form.querySelector('#fName').value.trim(),
    email: form.querySelector('#fEmail').value.trim(),
    phone: form.querySelector('#fPhone').value.trim(),
    service_slug: form.querySelector('#fService').value,
    preferred_date: form.querySelector('#fDate').value || null,
    design_requirements: form.querySelector('#fMessage').value.trim() || null,
  };

  try {
    const res = await fetch(`${API_BASE}/api/consultations`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
    });
    if (!res.ok) throw new Error('Request failed');
    // ...existing success UI swap...
  } catch (err) {
    // show an inline error state to the user
  }
});
```

And to render the Lookbook grid dynamically instead of the static
markup:

```javascript
const res = await fetch(`${API_BASE}/api/portfolio`);
const { items } = await res.json();
// items.forEach(item => build a .look element from item.image_url,
// item.title, item.category_label, item.look_number)
```
